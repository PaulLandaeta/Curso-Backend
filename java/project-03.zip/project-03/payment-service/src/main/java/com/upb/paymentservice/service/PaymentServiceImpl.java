package com.upb.paymentservice.service;

import org.springframework.stereotype.Service;

public class PaymentServiceImpl implements PaymentService{
}
