package com.upb.paymentservice.service;

public interface PaymentService {
}
